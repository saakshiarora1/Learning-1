# Spotify-Clone-using-html-and-css
This is a clone of spotify using only html and css as part of practice for my web developmet skills. Please contact me through for any suggestions or compliments.  

Email-ID : vamsidhard2002@gmail.com
           dv5932@srmist.edu.in
